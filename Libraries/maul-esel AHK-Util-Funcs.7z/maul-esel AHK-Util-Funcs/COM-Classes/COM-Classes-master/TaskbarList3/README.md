## TaskbarList3 README:
This class implements the ***ITaskbarList3*** interface.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/TaskbarList3)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/dd391692)
* [License: LGPL](http://www.gnu.org/licenses/lgpl-2.1.txt)