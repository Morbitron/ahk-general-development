## RichEditOLE README:
This class implements the ***IRichEditOLE*** interface.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/RichEditOLE)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/bb774306)
* [License: LGPL](http://www.gnu.org/licenses/lgpl-2.1.txt)