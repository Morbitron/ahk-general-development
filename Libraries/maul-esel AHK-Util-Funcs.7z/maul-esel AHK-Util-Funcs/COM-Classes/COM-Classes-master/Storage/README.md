## Storage README:
This class implements the ***IStorage*** interface.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/Storage)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/aa380015%28v=vs.85%29.aspx)
* [License: LGPL](http://www.gnu.org/licenses/lgpl-2.1.txt)