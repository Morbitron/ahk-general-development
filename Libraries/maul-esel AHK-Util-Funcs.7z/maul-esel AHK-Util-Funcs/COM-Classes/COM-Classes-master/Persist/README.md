## Persist README:
This class implements the ***IPersist*** interface.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/Persist)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/ms688695)
* [License: LGPL](http://www.gnu.org/licenses/lgpl-2.1.txt)