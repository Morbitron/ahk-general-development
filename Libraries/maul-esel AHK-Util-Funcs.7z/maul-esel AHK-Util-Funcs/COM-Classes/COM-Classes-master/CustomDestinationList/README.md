## CustomDestinationList README:
This class implements the ***ICustomDestinationList*** interface.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/CustomDestinationList)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/dd378402)
* [License: LGPL](http://www.gnu.org/licenses/lgpl-2.1.txt)