## ShellLinkW README:
This class implements the ***IShellLinkW*** interface.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/ShellLinkW)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/bb774950)
* [License: LGPL](http://www.gnu.org/licenses/lgpl-2.1.txt)