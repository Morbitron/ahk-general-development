## TypeLib README:
This class implements the ***ITypeLib*** interface.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/TypeLib)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/ms221549)
* [License: LGPL](http://www.gnu.org/licenses/lgpl-2.1.txt)