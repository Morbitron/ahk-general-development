## TaskbarList4 README:
This class implements the ***ITaskbarList4*** interface.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/TaskbarList4)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/dd562040)
* [License: LGPL](http://www.gnu.org/licenses/lgpl-2.1.txt)