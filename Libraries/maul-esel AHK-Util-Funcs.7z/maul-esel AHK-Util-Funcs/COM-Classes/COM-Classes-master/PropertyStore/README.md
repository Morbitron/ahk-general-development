## PropertyStore README:
This class implements the ***IPropertyStore*** interface.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/PropertyStore)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/bb761474)
* [License: LGPL](http://www.gnu.org/licenses/lgpl-2.1.txt)