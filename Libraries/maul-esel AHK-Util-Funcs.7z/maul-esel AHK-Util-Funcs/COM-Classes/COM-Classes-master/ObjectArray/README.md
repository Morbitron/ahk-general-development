## ObjectArray README:
This class implements the **IObjectArray** interface.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/ObjectArray)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/dd378311)
* [License: LGPL](http://www.gnu.org/licenses/lgpl-2.1.txt)