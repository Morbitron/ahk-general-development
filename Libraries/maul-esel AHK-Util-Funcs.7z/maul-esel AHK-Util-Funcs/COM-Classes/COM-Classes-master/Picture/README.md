## Picture README:
This class implements the ***IPicture*** interface.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/Picture)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/ms680761)
* [License: LGPL](http://www.gnu.org/licenses/lgpl-2.1.txt)