## UIAutomationCondition README:
This class implements the ***IUIAutomationCondition*** interface.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/UIAutomationCondition)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/ee671420)
* [License: LGPL](http://www.gnu.org/licenses/lgpl-2.1.txt)