## ShellLinkA README:
This class implements the ***IShellLinkA*** interface.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/ShellLinkA)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/bb774950)
* [License: LGPL](http://www.gnu.org/licenses/lgpl-2.1.txt)