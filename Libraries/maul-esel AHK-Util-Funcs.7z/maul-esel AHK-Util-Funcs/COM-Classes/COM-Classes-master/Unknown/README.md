## Unknown README:
This class basically implements the ***IUnknown*** interface and class meta-functions.
It is intended to be a base class, not for direct use.

## Links:
* [Author: maul.esel](https://github.com/maul-esel)
* [Documentation](http://maul-esel.github.com/COM-Classes/master/Unknown)
* [msdn Documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/ms680509)
* [License: unlicensed](http://unlicense.org/)