# Test Page

## Something
You might want to DIE. In order to **do** so (or **no\*\*t**) use `SomeClass.Func()`:
> o := new SomeClass() ; This might want to DIEDIEDIE
> o.Func()
> ; This is a separate line
> o := "" ; This line is not needed
> MsgBox What; is this
> try
> {
>     oSC := ComObjCreate("ScriptControl")
>     
>     oSC := ""
> }
Else you *cannot* DIE.

## Other

> what ; is this

* This is dinner: `new CDinner()`
* This is dinnerer

This is an image: ![](ahklogo.png)

Oh, and I like pie: `CPie.Eat()`. Use `<pre class="NoIndent">` and `&amp;` for dinner.
* Toast
* Spaghetti
This continues here

## List demo

1. First item
2. Second item
12983698346. Third item

a. First item!
z. Second item!
q. Third item!

Some math: `2\**3 + 5\*4`

### For more information

Go to [Google \[although it may not be a good idea\]](http://www.google.com/search?q=AutoHotkey&encoding=UTF-8) or
to the [forums](http://www.autohotkey.com/forum/).

There's a line break  
in this dinner.
